using Microsoft.AspNetCore.Mvc;
using EcommerceMvcProject.Data;
using EcommerceMvcProject.Models;
using System.Linq;
using System.Threading.Tasks;

namespace EcommerceMvcProject.Controllers
{
    public class CategoriesController : Controller
    {
        private readonly ApplicationDbContext _db;
        public CategoriesController(ApplicationDbContext db) { _db = db; }

        public IActionResult Index()
        {
            var cats = _db.Categories.ToList();
            return View(cats);
        }

        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Category category)
        {
            if (ModelState.IsValid)
            {
                _db.Categories.Add(category);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(category);
        }
    }
}
