using Microsoft.AspNetCore.Mvc;

namespace EcommerceMvcProject.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
