using System.Collections.Generic;

namespace EcommerceMvcProject.Models
{
    public class Brand
    {
        public int BrandID { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public virtual ICollection<Product>? Products { get; set; }
    }
}
