using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EcommerceMvcProject.Models
{
    public class Product
    {
        public int ProductID { get; set; }

        [Required]
        public string? Name { get; set; }
        public string? Description { get; set; }

        [Range(0, double.MaxValue)]
        public decimal Price { get; set; }

        public int Stock { get; set; }
        public string? ImageUrl { get; set; }
        public int CategoryID { get; set; }
        public int? SellerID { get; set; }
        public int? BrandID { get; set; }

        public virtual Category? Category { get; set; }
        public virtual Brand? Brand { get; set; }
        public virtual User? Seller { get; set; }
        public virtual ICollection<ProductImage>? ProductImages { get; set; }
        public virtual ICollection<ProductSpec>? ProductSpecs { get; set; }
        public virtual ICollection<ProductVariant>? Variants { get; set; }
        public virtual ICollection<ProductTag>? ProductTags { get; set; }
    }
}
