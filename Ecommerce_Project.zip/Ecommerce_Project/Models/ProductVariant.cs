namespace EcommerceMvcProject.Models
{
    public class ProductVariant
    {
        public int VariantID { get; set; }
        public int ProductID { get; set; }
        public string? VariantName { get; set; }
        public decimal? Price { get; set; }
        public int Stock { get; set; }
        public string? SKU { get; set; }
        public virtual Product? Product { get; set; }
    }
}
