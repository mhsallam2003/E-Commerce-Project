using System;
using System.Collections.Generic;

namespace EcommerceMvcProject.Models
{
    public class Order
    {
        public int OrderID { get; set; }
        public int UserID { get; set; }
        public decimal TotalPrice { get; set; }
        public string? Status { get; set; } // Pending, Processing, Shipped, Delivered
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public int ShippingAddressID { get; set; }
        public virtual User? User { get; set; }
        public virtual Address? ShippingAddress { get; set; }
        public virtual ICollection<OrderItem>? OrderItems { get; set; }
    }
}
